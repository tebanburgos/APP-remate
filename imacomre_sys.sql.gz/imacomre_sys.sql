-- MySQL dump 10.13  Distrib 5.5.50, for Linux (x86_64)
--
-- Host: localhost    Database: imacomre_sys
-- ------------------------------------------------------
-- Server version	5.5.50-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(45) DEFAULT NULL,
  `apellido_paterno` varchar(60) DEFAULT NULL,
  `apellido_materno` varchar(30) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `clave` varchar(123) DEFAULT NULL,
  `rut` varchar(12) DEFAULT NULL,
  `telefono` varchar(32) DEFAULT NULL,
  `celular` varchar(32) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `activo_admin` int(1) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `enviar_mail` tinyint(1) DEFAULT NULL,
  `token_activacion` varchar(40) DEFAULT NULL,
  `token_recuperar_clave` varchar(40) DEFAULT NULL,
  `permiso` text NOT NULL,
  `creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`admin_id`, `nombres`, `apellido_paterno`, `apellido_materno`, `email`, `clave`, `rut`, `telefono`, `celular`, `activo`, `activo_admin`, `fecha_nacimiento`, `fecha_creacion`, `enviar_mail`, `token_activacion`, `token_recuperar_clave`, `permiso`, `creacion`) VALUES (1,'Cristian','Yanez','Lagos','soporte@imacom.cl','$1$hPGBMSfK$9jRg2jMBCKMy9gj4slspR.','0','0','56123467',1,1,NULL,NULL,0,NULL,NULL,'a:1:{i:0;s:5:\"admin\";}','2015-08-18 19:14:12'),(2,'Esteban','Burgos','Viveros','esteban.imacom@gmail.com','$1$hPGBMSfK$9jRg2jMBCKMy9gj4slspR.','0','0','77665730',1,1,NULL,NULL,0,NULL,'9a6d6206f0c90c29f4f5521c078b19c6b04d1e8e','a:1:{i:0;s:5:\"admin\";}','2015-08-18 19:23:39');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `categoria_id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_nombre` varchar(128) NOT NULL,
  `categoria_estado` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`categoria_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` (`categoria_id`, `categoria_nombre`, `categoria_estado`) VALUES (1,'(Sin categoría)','activo'),(2,'Auto o motos','activo'),(5,'Camiones y autobuses','activo'),(8,'Industrial, maquinaria y equipos','activo'),(12,'Maquinaria de construcción y agrícola','activo'),(15,'Chatarras, materiales y residuos','activo'),(20,'Movimiento y transporte','activo'),(21,'Hogar y decoración','activo'),(22,'Embarcaciones & Aeronaves','activo'),(23,'Electrónicos, informática & bazar','activo'),(24,'Bebidas y viajes','activo'),(25,'Joyas y Relojes','activo'),(30,'Categoría de prueba 001111','desactivado'),(31,'Categoría de prueba 002','desactivado'),(32,'Categoría de prueba Imacom1','desactivado'),(34,'Categoría de prueba 0031','desactivado'),(35,'Categoría de prueba Imacom 1001','desactivado'),(36,'Categoría de prueba 3','desactivado'),(37,'Prueba','activo'),(38,'Super Prueba','activo'),(39,'Prueba RSI','activo');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuraciones`
--

DROP TABLE IF EXISTS `configuraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuraciones` (
  `configuracion_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuracion_url` varchar(255) DEFAULT NULL,
  `configuracion_admin` varchar(128) DEFAULT NULL,
  `configuracion_password` varchar(123) DEFAULT NULL,
  PRIMARY KEY (`configuracion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuraciones`
--

LOCK TABLES `configuraciones` WRITE;
/*!40000 ALTER TABLE `configuraciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `configuraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favoritos`
--

DROP TABLE IF EXISTS `favoritos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favoritos` (
  `favorito_id` int(11) NOT NULL AUTO_INCREMENT,
  `ofertante_id` int(11) NOT NULL,
  `lote_id` int(11) NOT NULL,
  PRIMARY KEY (`favorito_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favoritos`
--

LOCK TABLES `favoritos` WRITE;
/*!40000 ALTER TABLE `favoritos` DISABLE KEYS */;
/*!40000 ALTER TABLE `favoritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fotos`
--

DROP TABLE IF EXISTS `fotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fotos` (
  `foto_id` int(11) NOT NULL AUTO_INCREMENT,
  `lote_id` int(11) NOT NULL,
  `foto_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`foto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=467 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fotos`
--

LOCK TABLES `fotos` WRITE;
/*!40000 ALTER TABLE `fotos` DISABLE KEYS */;
INSERT INTO `fotos` (`foto_id`, `lote_id`, `foto_url`) VALUES (7,3,'chevroletaveo.jpg'),(8,3,'grandwallflorid.jpg'),(9,3,'hyundaielantra.jpg'),(10,3,'hyundaielantra.jpg'),(11,3,'hyundaielantra.jpg'),(22,6,'chevroletaveo.jpg'),(23,6,'daf.jpg'),(24,6,'hyundaielantra.jpg'),(25,6,'hyundaielantra.jpg'),(26,6,'hyundaielantra.jpg'),(27,7,'chevroletaveo.jpg'),(28,7,''),(29,7,''),(30,7,''),(31,7,''),(32,8,'volvo.jpg'),(33,8,''),(34,8,''),(35,8,''),(36,8,''),(42,9,'hyundaielantra.jpg'),(43,9,''),(44,9,''),(45,9,''),(46,9,''),(47,10,'mazda2.jpg'),(48,10,''),(49,10,''),(50,10,''),(51,10,''),(152,31,'kia.jpg'),(153,31,NULL),(154,31,NULL),(155,31,NULL),(156,31,NULL),(157,32,'kia1.jpg'),(158,32,NULL),(159,32,NULL),(160,32,NULL),(161,32,NULL),(162,33,'chevroletaveo1.jpg'),(163,33,'0_11123014301.jpg'),(164,33,'kia2.jpg'),(165,33,NULL),(166,33,NULL),(167,34,'daf1.jpg'),(168,34,NULL),(169,34,NULL),(170,34,NULL),(171,34,NULL),(172,35,'Homero-movil.jpg'),(173,35,NULL),(174,35,NULL),(175,35,NULL),(176,35,NULL),(177,36,'Homero-movil1.jpg'),(178,36,NULL),(179,36,NULL),(180,36,NULL),(181,36,NULL),(182,37,'Homero-movil1.jpg'),(183,37,NULL),(184,37,NULL),(185,37,NULL),(186,37,NULL),(187,38,'21300-MLC20207831363_122014-O.jpg'),(188,38,NULL),(189,38,NULL),(190,38,NULL),(191,38,NULL),(192,39,'calvin_and_hobbes_0011.jpg'),(193,39,'logo_400x4001.jpeg'),(194,39,NULL),(195,39,NULL),(196,39,NULL),(197,40,'Penguins.jpg'),(198,40,'Tulips.jpg'),(199,40,NULL),(200,40,NULL),(201,40,NULL),(202,41,'chevrolet-luv-22-doble-cabina-antildeo-2001-unico_28ab3492e2_3.jpg'),(203,41,'de+oportunidad+se+vende+camioneta+chevrolet+luv+doble+cabina+full+equipo+3+2+6v+quito+pichincha+ecuador__B05BCE_3.jpg'),(204,41,'chevrolet_luv_v6_2_4_4x4_doble_cabina_97246366382203460.jpg'),(205,41,NULL),(206,41,NULL),(207,42,'7imf5h6tm95pn2shj9fthrbdn4_201412230930475499607701be7.jpg'),(208,42,'kia-besta-30-escolar-2004_a03a68868c_3.jpg'),(209,42,NULL),(210,42,NULL),(211,42,NULL),(212,43,'mitsubishi_montero_3_2_di_d_instyle_2510123456181223313.jpg'),(213,43,'redimensionar_(1).jpg'),(214,43,'redimensionar.jpg'),(215,43,NULL),(216,43,NULL),(217,44,'volvo,-remolque-193168.jpg'),(218,44,'4-Volvo-Quester.jpg'),(219,44,NULL),(220,44,NULL),(221,44,NULL),(222,45,'web_negro1.png'),(223,45,'black-businessman-256.png'),(224,45,'fono_negro1.png'),(225,45,NULL),(226,45,NULL),(227,46,'foto_0000001120160220010631.jpg'),(228,46,'list_logo20maco20nuevo.jpg'),(229,46,NULL),(230,46,NULL),(231,46,NULL),(232,47,'IMG_3677.JPG'),(233,47,NULL),(234,47,NULL),(235,47,NULL),(236,47,NULL),(237,48,'vendo-camion-mbenz-711-antildeo-2005_bfa800094a_31.jpg'),(238,48,NULL),(239,48,NULL),(240,48,NULL),(241,48,NULL),(242,123,'chevroletaveo0011.jpg'),(243,123,'chevroletaveo0021.jpg'),(244,123,NULL),(245,123,NULL),(246,123,NULL),(247,124,'chevroletaveo0012.jpg'),(248,124,'daf2.jpg'),(249,124,NULL),(250,124,NULL),(251,124,NULL),(252,125,'kia3.jpg'),(253,125,'mazda21.jpg'),(254,125,NULL),(255,125,NULL),(256,125,NULL),(257,126,'camion+freightliner+fl+80+1997+santiago+metropolitana+de+santiago+chile__BED024_11.jpg'),(258,126,'freightliner-fl80-tolva-antildeo-1996_60f3b95_3.jpg'),(259,126,NULL),(260,126,NULL),(261,126,NULL),(262,129,'foto_ejemplo.jpg'),(263,130,'foto_ejemplo.jpg'),(264,131,'foto_ejemplo.jpg'),(265,132,'foto_ejemplo.jpg'),(266,133,'foto_ejemplo.jpg'),(267,134,'foto_ejemplo.jpg'),(268,135,'foto_ejemplo.jpg'),(269,136,'foto_ejemplo.jpg'),(270,137,'foto_ejemplo.jpg'),(271,138,'23748ev7i239lls7dq6o260_20160317111154156eabb2a76530.jpg'),(272,139,'16salfa_tractor_dc_-2.jpg'),(273,140,'b68863833b3d7d8a1f1bb8dc11c9613105b54063.bin_.jpg'),(274,141,'C683936.jpg'),(275,142,'bulldozer+caterpillar+d4d+osorno+los+lagos+chile__222C53_4.jpg'),(276,143,'foto_ejemplo.jpg'),(277,144,'foto_ejemplo.jpg'),(278,145,'foto_ejemplo.jpg'),(279,146,'foto_ejemplo.jpg'),(280,147,'foto_ejemplo.jpg'),(281,148,'foto_ejemplo.jpg'),(282,149,'foto_ejemplo.jpg'),(283,150,'foto_ejemplo.jpg'),(284,151,'foto_ejemplo.jpg'),(285,152,'foto_ejemplo.jpg'),(286,153,'foto_ejemplo.jpg'),(287,154,'foto_ejemplo.jpg'),(288,155,'foto_ejemplo.jpg'),(289,156,'foto_ejemplo.jpg'),(290,157,'foto_ejemplo.jpg'),(291,158,'foto_ejemplo.jpg'),(292,159,'foto_ejemplo.jpg'),(293,160,'foto_ejemplo.jpg'),(294,161,'foto_ejemplo.jpg'),(295,162,'foto_ejemplo.jpg'),(296,163,'foto_ejemplo.jpg'),(297,164,'foto_ejemplo.jpg'),(298,165,'foto_ejemplo.jpg'),(299,166,'foto_ejemplo.jpg'),(300,167,'foto_ejemplo.jpg'),(301,168,'foto_ejemplo.jpg'),(302,169,'foto_ejemplo.jpg'),(303,170,'foto_ejemplo.jpg'),(304,171,'foto_ejemplo.jpg'),(305,172,'foto_ejemplo.jpg'),(306,173,'foto_ejemplo.jpg'),(307,174,'foto_ejemplo.jpg'),(308,175,'foto_ejemplo.jpg'),(309,176,'foto_ejemplo.jpg'),(310,177,'foto_ejemplo.jpg'),(311,178,'foto_ejemplo.jpg'),(312,179,'foto_ejemplo.jpg'),(313,180,'foto_ejemplo.jpg'),(314,181,'foto_ejemplo.jpg'),(315,182,'foto_ejemplo.jpg'),(316,183,'skc-rental-arriendo-de-bulldozer-bulldozer-caterpillar-d6r-serie-3-606195-FGR.jpg'),(317,183,'recmaq-bulldozer-bulldozer-caterpillar-dk8-con-cabina-original-601087-FGR.jpg'),(318,183,'bulldozer_cat_d6r_1170122449094337507.jpg'),(319,183,NULL),(320,183,NULL),(321,184,'l1.jpg'),(322,185,'l2.jpg'),(323,186,'l3.jpg'),(324,187,'l4.jpg'),(325,188,'l5.jpg'),(326,189,'l6.jpg'),(327,114,'l83.jpg'),(328,115,'l2.jpg'),(329,116,'l3.jpg'),(330,117,'l4.jpg'),(331,118,'l5.jpg'),(332,119,'l5.jpg'),(333,120,'l7.jpg'),(334,121,'l8.jpg'),(335,122,'l8.jpg'),(336,114,'l92.jpg'),(337,114,''),(338,114,''),(339,114,''),(340,115,NULL),(341,115,NULL),(342,115,NULL),(343,115,NULL),(344,116,NULL),(345,116,NULL),(346,116,NULL),(347,116,NULL),(348,117,NULL),(349,117,NULL),(350,117,NULL),(351,117,NULL),(352,118,NULL),(353,118,NULL),(354,118,NULL),(355,118,NULL),(356,119,NULL),(357,119,NULL),(358,119,NULL),(359,119,NULL),(360,120,NULL),(361,120,NULL),(362,120,NULL),(363,120,NULL),(364,121,NULL),(365,121,NULL),(366,121,NULL),(367,121,NULL),(368,122,NULL),(369,122,NULL),(370,122,NULL),(371,122,NULL),(372,190,'rogator-01.jpg'),(373,190,''),(374,190,''),(375,190,''),(376,190,''),(377,191,'8bb30d07.jpg'),(378,191,''),(379,191,''),(380,191,''),(381,191,''),(382,192,'tractor-agricola-john-deere-5300-maquinaria-de-construccion-22568-MLM20232131483_012015-F.jpg'),(383,192,''),(384,192,''),(385,192,''),(386,192,''),(387,193,'tractor-new-holland.png'),(388,193,''),(389,193,''),(390,193,''),(391,193,''),(392,194,'51f3fc9adc.jpg'),(393,194,''),(394,194,''),(395,194,''),(396,194,''),(397,195,'alquileragricola.jpg'),(398,195,''),(399,195,''),(400,195,''),(401,195,''),(402,196,'alquileragricola1.jpg'),(403,196,''),(404,196,''),(405,196,''),(406,196,''),(407,197,'tractor-agricola-john-deere-5300-maquinaria-de-construccion-22508-MLM20232131711_012015-F.jpg'),(408,197,''),(409,197,''),(410,197,''),(411,197,''),(412,198,'51f3fc9adc1.jpg'),(413,198,''),(414,198,''),(415,198,''),(416,198,''),(417,138,''),(418,138,''),(419,138,''),(420,138,''),(421,139,''),(422,139,''),(423,139,''),(424,139,''),(425,140,''),(426,140,''),(427,140,''),(428,140,''),(429,141,''),(430,141,''),(431,141,''),(432,141,''),(433,142,''),(434,142,''),(435,142,''),(436,142,''),(437,199,'cvc-cadena-protectora-de-neumaticos-cadenas-protectoras-para-neumaticos-de-maquinaria-pesada-546870-FGR.jpg'),(438,199,NULL),(439,199,NULL),(440,199,NULL),(441,199,NULL),(442,200,'Gruas-remolques-022.jpg'),(443,200,NULL),(444,200,NULL),(445,200,NULL),(446,200,NULL),(447,201,'vendo-furgon-kia-besta-27_51d4122820_3.jpg'),(448,201,NULL),(449,201,NULL),(450,201,NULL),(451,201,NULL),(452,202,'2285.jpg'),(453,202,NULL),(454,202,NULL),(455,202,NULL),(456,202,NULL),(457,203,'slider_home_1.jpg'),(458,203,NULL),(459,203,NULL),(460,203,NULL),(461,203,NULL),(462,204,'l93.jpg'),(463,204,NULL),(464,204,NULL),(465,204,NULL),(466,204,NULL);
/*!40000 ALTER TABLE `fotos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `garantias`
--

DROP TABLE IF EXISTS `garantias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `garantias` (
  `garantia_id` int(11) NOT NULL AUTO_INCREMENT,
  `ofertante_id` int(11) NOT NULL,
  `remate_id` int(11) NOT NULL,
  `garantia_estado` varchar(32) DEFAULT NULL,
  `garantia_tipo_pago` varchar(128) DEFAULT NULL,
  `garantia_numero_pago` varchar(64) DEFAULT NULL,
  `garantia_devolucion` varchar(32) DEFAULT NULL,
  `garantia_fecha_ingreso` datetime DEFAULT NULL,
  `garantia_archivo_adjunto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`garantia_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `garantias`
--

LOCK TABLES `garantias` WRITE;
/*!40000 ALTER TABLE `garantias` DISABLE KEYS */;
INSERT INTO `garantias` (`garantia_id`, `ofertante_id`, `remate_id`, `garantia_estado`, `garantia_tipo_pago`, `garantia_numero_pago`, `garantia_devolucion`, `garantia_fecha_ingreso`, `garantia_archivo_adjunto`) VALUES (9,3,62,'Pagada','Transferencia','1','Pendiente','0000-00-00 00:00:00','http://rsiauctions.com/uploads/garantias/62/comprobante.txt'),(10,3,43,'Revisando','Transferencia','1','Pendiente','0000-00-00 00:00:00','http://re-remate2.s2.imacom.cl/uploads/garantias/43/garantilla.txt'),(11,4,62,'Pagada','Transferencia','1','Pendiente','0000-00-00 00:00:00','http://re-remate2.s2.imacom.cl/uploads/garantias/62/VEH_500124432362_cjsh49.pdf'),(12,16,73,'Pagada','Transferencia','1','Pendiente','0000-00-00 00:00:00','http://re-remate2.s2.imacom.cl/uploads/garantias/73/certificado-en-blanco-espanol-20744546.jpg'),(18,16,72,'Pagada','Transferencia','1','Pendiente','2016-05-26 18:22:37','http://re-remate2.s2.imacom.cl/uploads/garantias/72/emojis-google3.jpg'),(19,12,73,'Revisando','Transferencia','1','Pendiente','2016-05-27 16:52:43','http://re-remate2.s2.imacom.cl/uploads/garantias/73/logo_remate.jpg'),(20,12,72,'Pagada','Transferencia','1','Pendiente','2016-05-28 09:58:49','http://re-remate2.s2.imacom.cl/uploads/garantias/72/Sin_titulo.jpg'),(21,13,72,'Pagada','Transferencia','1','Pendiente','2016-05-28 14:02:31','http://re-remate2.s2.imacom.cl/uploads/garantias/72/CQrkWe2UYAAidBS.jpg_large_.jpg'),(22,3,67,'Pagada','Transferencia','1','Pendiente','2016-05-31 12:57:16','http://re-remate2.s2.imacom.cl/uploads/garantias/67/Listado_de_juegos_XBOX360,KINECTS,PS3,_WII,BLU-RAY,3D,BLURAY_ANIME,PELICULAS_DEL_25_DE_MAYO_DEL_2016.xls'),(23,4,75,'Pagada','Transferencia','1','Pendiente','2016-05-31 15:29:29','http://re-remate2.s2.imacom.cl/uploads/garantias/75/num.txt'),(24,3,75,'Pagada','Transferencia','1','Pendiente','2016-05-31 16:13:06','http://re-remate2.s2.imacom.cl/uploads/garantias/75/Listado_de_juegos_XBOX360,KINECTS,PS3,_WII,BLU-RAY,3D,BLURAY_ANIME,PELICULAS_DEL_25_DE_MAYO_DEL_2016.xls'),(25,17,73,'Pagada','Transferencia','1','Pendiente','2016-06-02 17:06:01','http://re-remate2.s2.imacom.cl/uploads/garantias/73/Garantia-.jpg');
/*!40000 ALTER TABLE `garantias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes`
--

DROP TABLE IF EXISTS `lotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lotes` (
  `lote_id` int(11) NOT NULL AUTO_INCREMENT,
  `remate_id` int(11) NOT NULL,
  `tipo_id` int(11) NOT NULL,
  `marca_id` int(11) NOT NULL,
  `lote_modelo` varchar(125) DEFAULT NULL,
  `lote_ganador_id` int(11) DEFAULT '-1',
  `lote_nombre` varchar(128) NOT NULL,
  `lote_descripcion` varchar(1024) DEFAULT NULL,
  `lote_fecha_inicio` datetime NOT NULL,
  `lote_fecha_cierre` datetime NOT NULL,
  `lote_contador_visita` int(11) NOT NULL,
  `lote_contador_puja` int(11) DEFAULT NULL,
  `lote_estado` varchar(32) NOT NULL,
  `lote_puja_minima` int(11) NOT NULL,
  `lote_incremento` int(11) NOT NULL,
  `lote_valor_actual` bigint(20) DEFAULT NULL,
  `lote_documento_adjunto` varchar(255) NOT NULL,
  `lote_link_video` varchar(255) DEFAULT NULL,
  `lote_comision` float NOT NULL,
  PRIMARY KEY (`lote_id`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes`
--

LOCK TABLES `lotes` WRITE;
/*!40000 ALTER TABLE `lotes` DISABLE KEYS */;
INSERT INTO `lotes` (`lote_id`, `remate_id`, `tipo_id`, `marca_id`, `lote_modelo`, `lote_ganador_id`, `lote_nombre`, `lote_descripcion`, `lote_fecha_inicio`, `lote_fecha_cierre`, `lote_contador_visita`, `lote_contador_puja`, `lote_estado`, `lote_puja_minima`, `lote_incremento`, `lote_valor_actual`, `lote_documento_adjunto`, `lote_link_video`, `lote_comision`) VALUES (3,5,9,7,'Besta',3,'Lote 2','Vehículo Sedan','2015-09-22 15:00:00','2016-03-09 12:00:00',44,9,'finalizado',2000,500,18000,'certificado.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(6,1,14,4,'(Industria, maquinaria o equipo genérico sin modelo)',-1,'Lote 6','Vehículo Sedan','2015-09-22 15:00:00','2015-11-05 21:00:00',10,0,'finalizado',2000,500,2000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(7,26,6,6,'(Chevrolet sin modelo)',-1,'Lote 7','Auto Sedan','2015-11-25 09:00:00','2016-03-15 11:00:00',3,0,'finalizado',3000,3000,3000,'certificado002.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(8,26,6,2,'(Auto o moto genérica sin modelo)',7,'Lote 8','Volvo en buen estado','2015-11-30 09:00:00','2016-03-18 01:00:00',3,1,'finalizado',5000,100,6800,'certificado.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(9,43,9,9,'(Hyundai sin modelo)',14,'Lote 1','Hyundai ElAntra con poco uso','2015-12-21 10:00:00','2016-04-20 20:00:00',33,3,'finalizado',5000,100,5900,'certificado00001.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(10,43,6,2,'(Auto o moto genérica sin modelo)',-1,'Lote 2','Mazda2. Foto referencial','2016-01-05 22:00:00','2016-05-04 09:00:00',13,0,'finalizado',5000,100,5000,'certificado00002.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(31,41,6,7,'(Kia sin modelo)',7,'Lote 2','Kia con poco uso. Foto referencial','2015-11-01 23:00:00','2016-03-18 00:00:00',11,1,'finalizado',1000,10,1010,'cert.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(32,41,6,7,'(Kia sin modelo)',3,'Lote 3','Kia en perfecto estado. Foto referencial','2014-12-04 23:00:00','2016-12-04 01:00:00',62,1,'finalizado',1000,10,1020,'cert1.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(33,41,2,2,'(Auto o moto genérica sin modelo)',-1,'Lote 4','Chevrolet Aveo con poco uso','2015-12-09 03:00:00','2016-12-01 23:00:00',51,0,'finalizado',1000,10,1000,'certificado1.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(34,40,2,2,'(Kia sin modelo)',-1,'Lote 1','Auto camión','2015-12-10 01:00:00','2016-03-16 23:00:00',11,0,'finalizado',1000,10,1000,'cert2.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(35,46,6,6,'(Chevrolet sin modelo)',12,'Lote 1','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce venenatis neque ornare, suscipit dui quis, molestie risus. Integer auctor sed felis nec sollicitudin. Mauris gravida, dolor feugiat placerat consectetur, arcu arcu semper erat, et ornare massa metus id sem. Etiam mattis nunc sem. Donec hendrerit congue urna id gravida. Suspendisse potenti. In hac habitasse platea dictumst. Nunc malesuada tempor diam ac faucibus. Ut gravida sapien ut erat interdum, a laoreet neque pellentesque. Donec in ex nec elit ullamcorper vehicula.\n\nNullam non varius metus. Quisque sed sagittis nisl. Vestibulum accumsan est et ante euismod, ac varius augue pretium. Nullam feugiat pretium malesuada. Suspendisse volutpat massa sodales molestie luctus. Integer id ipsum magna. In ultricies in magna in ultrices. Donec tempus sapien in lorem auctor aliquam. Pellentesque tortor massa, rhoncus porta malesuada et, vestibulum at ligula. Aenean egestas ligula at ipsum maximus dictum. Cras dignissim suscipit sagittis.\n\nEtiam ligula ante, ','2016-02-05 12:00:00','2016-03-10 12:00:00',24,3,'finalizado',5000,100,5500,'certificado-en-blanco-espanol-20744546.jpg','https://vimeo.com/78362278',0.12),(37,46,33,2,'(Auto o moto genérica sin modelo)',-1,'Lote 2','Chatarra\n\n\nasdf\nasd\nfa\ndf\nasf\nasd\nfa\nf\nadf\nad\nfs\nasdf\nasdfasd\nfadfs\na\nsdf\nasdf','2016-02-08 23:00:00','2016-03-14 21:00:00',3,0,'finalizado',2000,100,2000,'certificado-en-blanco-espanol-207445461.jpg','https://vimeo.com/78362278',0.12),(38,46,6,8,'Sin modelo',-1,'Lote 3','Descrip 001','2016-02-08 23:00:00','2016-03-25 19:00:00',0,0,'finalizado',5000,10,5000,'certificado-en-blanco-espanol-207445462.jpg','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(39,57,6,87,'Sin modelo',-1,'Lote 1','lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore ','2016-02-23 15:59:00','2016-05-17 18:25:00',14,0,'finalizado',5000,100,5000,'certificado3.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(40,58,6,6,'Sin modelo',-1,'Lote 1','Descripcion 001','2016-03-31 19:00:00','2016-04-01 16:00:00',3,0,'finalizado',1000,5000,1000,'Koala.jpg','https://www.youtube.com/watch?v=6sdLAFRsZY0',0.12),(41,59,6,6,'LUV',-1,'Lote 1','Descripción de prueba 001','2016-03-27 18:50:00','2016-03-31 18:50:00',1,0,'finalizado',5000000,100000,5000000,'certificado4.JPG','https://www.youtube.com/watch?v=5fpSAbtBgdI',0.12),(42,59,8,7,'Besta',-1,'Lote 2','Furgón usado 2004 usado.','2016-03-23 09:00:00','2016-03-31 11:30:00',1,0,'finalizado',3000000,100000,3000000,'certificado5.JPG','https://www.youtube.com/watch?v=5fpSAbtBgdI',0.12),(43,59,28,101,'Montero',-1,'Lote 3','Mitsubishi montero 3.2 did motion, negro, año 2010, 200000 km','2016-03-28 10:15:00','2016-03-31 10:15:00',0,0,'finalizado',5000000,200000,5000000,'certificado6.JPG','https://www.youtube.com/watch?v=5fpSAbtBgdI',0.12),(44,60,10,10,'Quester',-1,'Lote 1','Camión sin uso año 2015','2016-03-23 09:00:00','2016-04-10 10:00:00',6,0,'finalizado',5000000,200000,5000000,'certificado7.JPG','https://www.youtube.com/watch?v=5fpSAbtBgdI',0.12),(45,62,39,136,'nyrbvscds',-1,'Lote 1','ebrvdcs','2016-04-30 22:41:00','2016-05-20 22:41:00',19,0,'finalizado',5000,500,5000,'ONLINE_copia1.png','https://www.youtube.com/watch?v=drpUIHz66zE&index=45&list=PL40E731CAC9DC4B93',0.12),(46,64,48,19,'jjj',-1,'Lote 1','reloj que da la hora','2016-04-04 16:40:00','2016-04-04 16:45:00',4,0,'finalizado',5000,1000,5000,'tumblr_o50r7oQdBf1ue9j4wo1_1280.jpg','https://www.youtube.com/watch?v=ytYq3BCjTn8',0.12),(47,63,45,16,'BARCO',-1,'Lote 1','BARCO Y AVION','2016-04-05 16:39:00','2016-04-05 17:26:00',11,0,'finalizado',2000000,250000,2000000,'IMG_3577.JPG','https://www.youtube.com/watch?v=uGXWab_Nnhw',0.12),(48,62,39,139,'Sin modelo',4,'Lote 2','Descrip 001','2016-05-05 10:00:00','2016-05-20 10:00:00',84,4,'finalizado',450000,1000,464000,'certificado9.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(49,70,39,139,'Sin modelo',-1,'Lote 2','Descrip 001','2016-05-05 10:00:00','2016-05-20 10:00:00',39,0,'finalizado',450000,1000,450000,'certificado9.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(50,1,1,1,'1',1,'1','1','2016-05-03 00:00:00','2016-05-26 00:00:00',1,1,'1',1,1,1,'1','1',1),(51,62,9,10,'7',-1,'Lote 1','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,'finalizado',1000,1000,1000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(52,62,9,10,'7',-1,'Lote 2','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,'finalizado',2000,2000,2000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(53,62,9,10,'7',-1,'Lote 3','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,'finalizado',3000,3000,3000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(54,62,9,10,'7',-1,'Lote 4','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,'finalizado',4000,4000,4000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(55,62,9,10,'7',-1,'Lote 5','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,'finalizado',5000,5000,5000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(56,62,9,10,'7',-1,'Lote 6','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,'finalizado',6000,6000,6000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(57,62,9,10,'7',-1,'Lote 7','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',1,0,'finalizado',7000,7000,7000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(58,62,9,10,'7',-1,'Lote 8','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,'finalizado',8000,8000,8000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(59,62,9,10,'7',-1,'Lote 9','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,'finalizado',9000,9000,9000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(114,67,78,191,'(Sin modelo)',-1,'Lote 1','blablabla','2016-04-12 00:30:00','2016-06-30 12:00:00',64,0,'activo',10000,5000,10000,'ce011.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(115,67,9,10,'7',-1,'Lote 2','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-12 00:30:00','2016-06-30 12:00:00',2,0,'activo',2000,2000,2000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(116,67,9,10,'7',-1,'Lote 3','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-12 00:30:00','2016-06-30 12:00:00',2,0,'activo',3000,3000,3000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(117,67,9,10,'7',-1,'Lote 4','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-12 00:30:00','2016-06-30 12:00:00',0,NULL,'activo',4000,4000,4000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(118,67,9,10,'7',-1,'Lote 5','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-12 00:30:00','2016-06-30 12:00:00',5,0,'activo',5000,5000,5000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(119,67,9,10,'7',-1,'Lote 6','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-12 00:30:00','2016-06-30 12:00:00',7,0,'activo',6000,6000,6000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(120,67,9,10,'7',-1,'Lote 7','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-12 00:30:00','2016-06-30 12:00:00',0,NULL,'activo',7000,7000,7000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(121,67,9,10,'7',-1,'Lote 8','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-12 00:30:00','2016-06-30 12:00:00',0,NULL,'activo',8000,8000,8000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(122,67,9,10,'7',-1,'Lote 9','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-12 00:30:00','2016-06-30 12:00:00',0,NULL,'activo',9000,9000,9000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(123,72,76,189,'Sin modelo',12,'Lote 1','Descripcion 001','2016-05-18 18:18:00','2016-06-09 18:18:00',46,4,'finalizado',50000,5000,70000,'certificado10.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(124,73,78,191,'Sin modelo',16,'Lote 1','Descripción del lote 001','2016-05-25 18:30:00','2016-05-30 18:30:00',7,1,'finalizado',450000,50000,500000,'certificado11.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(125,74,75,188,'Sin modelo',-1,'Lote 1','Descripción 99','2016-05-31 18:27:00','2016-06-07 18:27:00',0,0,'finalizado',100000,20000,100000,'certificado-en-blanco-espanol-207445464.jpg','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(126,75,78,191,'Sin modelo',4,'Lote 1','Descrip maquinaria 01','2016-06-05 13:00:00','2016-06-12 13:00:00',100,15,'finalizado',10000,5000,160030,'emojis-google.jpg','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(127,62,9,10,'7',-1,'Lote 1','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',1,0,'finalizado',1000,1000,1000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(128,62,9,10,'7',-1,'Lote 1','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',1000,1000,1000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(129,62,9,10,'7',3,'Lote 1','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',5,1,'finalizado',1000,1000,2000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(130,62,9,10,'7',-1,'Lote 2','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',2000,2000,2000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(131,62,9,10,'7',-1,'Lote 3','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',3000,3000,3000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(132,62,9,10,'7',-1,'Lote 4','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',4000,4000,4000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(133,62,9,10,'7',-1,'Lote 5','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',5000,5000,5000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(134,62,9,10,'7',-1,'Lote 6','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',6000,6000,6000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(135,62,9,10,'7',-1,'Lote 7','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',7000,7000,7000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(136,62,9,10,'7',-1,'Lote 8','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',8000,8000,8000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(137,62,9,10,'7',-1,'Lote 9','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-04-30 22:17:00','2016-05-31 22:22:00',0,NULL,'finalizado',9000,9000,9000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(138,75,78,192,'Sin modelo',-1,'Lote 1','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-05-31 12:00:00','2016-06-30 12:00:00',1,0,'activo',1000,1000,1000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(139,75,38,192,'Sin modelo',-1,'Lote 2','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-05-31 12:00:00','2016-06-30 12:00:00',2,0,'activo',2000,2000,2000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(140,75,38,191,'Sin modelo',-1,'Lote 3','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-05-31 12:00:00','2016-06-30 12:00:00',1,0,'activo',3000,3000,3000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(141,75,78,129,'Sin modelo',-1,'Lote 4','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-05-31 12:00:00','2016-06-30 12:00:00',1,0,'activo',4000,4000,4000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(142,75,38,192,'Sin modelo',-1,'Lote 5','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-05-31 12:00:00','2016-06-30 12:00:00',2,0,'activo',5000,5000,5000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(183,73,78,192,'Sin modelo',17,'Lote 2','Camiones siniestrados o por parte','2016-06-01 15:00:00','2016-06-20 15:00:00',7,1,'finalizado',1000000,150000,1150000,'certificado12.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12),(184,68,38,129,'sin modelo',-1,'Lote 1','Lorem ipsum dolor sit amet  consectetur adipiscing elit. In quis condimentum sem. Nunc facilisis rutrum nulla vel efficitur. Aenean fermentum  ipsum ac mollis tempus  urna nunc sagittis diam  vel rhoncus odio nisl eget felis. Proin a nulla pharetra lectus suscipit blandit ut a ligula. Duis ac aliquam felis. Donec fringilla lacinia tristique. Vivamus fermentum quis orci non semper.','2016-04-10 00:00:00','2016-06-12 00:45:00',1,0,'finalizado',500000,50000,500000,'ce01.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(185,68,38,192,'sin modelo',-1,'Lote 2','Lorem ipsum dolor sit amet  consectetur adipiscing elit. In quis condimentum sem. Nunc facilisis rutrum nulla vel efficitur. Aenean fermentum  ipsum ac mollis tempus  urna nunc sagittis diam  vel rhoncus odio nisl eget felis. Proin a nulla pharetra lectus suscipit blandit ut a ligula. Duis ac aliquam felis. Donec fringilla lacinia tristique. Vivamus fermentum quis orci non semper.','2016-04-10 00:00:00','2016-06-15 00:45:00',0,NULL,'finalizado',250000,25000,250000,'ce02.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(186,68,38,129,'sin modelo',-1,'Lote 3','Lorem ipsum dolor sit amet  consectetur adipiscing elit. In quis condimentum sem. Nunc facilisis rutrum nulla vel efficitur. Aenean fermentum  ipsum ac mollis tempus  urna nunc sagittis diam  vel rhoncus odio nisl eget felis. Proin a nulla pharetra lectus suscipit blandit ut a ligula. Duis ac aliquam felis. Donec fringilla lacinia tristique. Vivamus fermentum quis orci non semper.','2016-04-10 00:00:00','2016-06-22 00:45:00',0,NULL,'finalizado',750000,250000,750000,'ce03.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(187,68,78,192,'sin modelo',-1,'Lote 4','Lorem ipsum dolor sit amet  consectetur adipiscing elit. In quis condimentum sem. Nunc facilisis rutrum nulla vel efficitur. Aenean fermentum  ipsum ac mollis tempus  urna nunc sagittis diam  vel rhoncus odio nisl eget felis. Proin a nulla pharetra lectus suscipit blandit ut a ligula. Duis ac aliquam felis. Donec fringilla lacinia tristique. Vivamus fermentum quis orci non semper.','2016-04-10 00:00:00','2016-06-24 00:45:00',0,NULL,'activo',1000000,100000,1000000,'ce04.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(188,68,78,129,'sin modelo',-1,'Lote 5','Lorem ipsum dolor sit amet  consectetur adipiscing elit. In quis condimentum sem. Nunc facilisis rutrum nulla vel efficitur. Aenean fermentum  ipsum ac mollis tempus  urna nunc sagittis diam  vel rhoncus odio nisl eget felis. Proin a nulla pharetra lectus suscipit blandit ut a ligula. Duis ac aliquam felis. Donec fringilla lacinia tristique. Vivamus fermentum quis orci non semper.','2016-04-10 00:00:00','2016-06-26 00:45:00',0,NULL,'activo',650000,50000,650000,'ce05.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(189,68,78,192,'sin modelo',-1,'Lote 6','Lorem ipsum dolor sit amet  consectetur adipiscing elit. In quis condimentum sem. Nunc facilisis rutrum nulla vel efficitur. Aenean fermentum  ipsum ac mollis tempus  urna nunc sagittis diam  vel rhoncus odio nisl eget felis. Proin a nulla pharetra lectus suscipit blandit ut a ligula. Duis ac aliquam felis. Donec fringilla lacinia tristique. Vivamus fermentum quis orci non semper.','2016-04-10 00:00:00','2016-06-29 00:45:00',0,NULL,'activo',450000,250000,450000,'ce06.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(190,77,38,192,'Sin modelo',-1,'Lote 1','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',0,NULL,'activo',1000,1000,1000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(191,77,38,191,'Sin modelo',-1,'Lote 2','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',1,0,'activo',2000,2000,2000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(192,77,78,192,'Sin modelo',-1,'Lote 3','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',0,NULL,'activo',3000,3000,3000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(193,77,38,192,'Sin modelo',-1,'Lote 4','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',1,0,'activo',4000,4000,4000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(194,77,78,192,'Sin modelo',-1,'Lote 5','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',0,NULL,'activo',5000,5000,5000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(195,77,78,191,'Sin modelo',-1,'Lote 6','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',0,NULL,'activo',6000,6000,6000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(196,77,78,192,'Sin modelo',-1,'Lote 7','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',0,NULL,'activo',7000,7000,7000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(197,77,78,192,'Sin modelo',-1,'Lote 8','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',0,NULL,'activo',8000,8000,8000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(198,77,78,192,'Sin modelo',-1,'Lote 9','Nunc orci eros, lobortis volutpat eros id, scelerisque consectetur libero.','2016-06-01 13:30:00','2016-07-29 13:30:00',0,NULL,'activo',9000,9000,9000,'certificado001.JPG','https://www.youtube.com/embed/60QS57C8zBw',0.12),(199,76,3,65,'Sin modelo',-1,'Lote 1','Excabadora en buen estado sin uso','2016-06-06 13:19:00','2016-06-24 13:19:00',0,0,'activo',200000,100000,200000,'certificado13.JPG','https://www.youtube.com/watch?v=oPqcsEmq-xM',0.12),(200,76,37,41,'Sin modelo',-1,'Lote 2','Grúa en buen estado','2016-06-07 13:40:00','2016-06-21 13:40:00',1,0,'finalizado',4000000,250000,4000000,'certificado-en-blanco-espanol-207445465.jpg','http://www.hino.cl/gruas_unic.php',0.12),(201,76,12,45,'Besta',-1,'Lote 3','Furgón 2012 papeles al día','2016-06-12 13:45:00','2016-06-20 13:45:00',0,0,'finalizado',2100000,10,2100000,'certificado-en-blanco-espanol-207445466.jpg','https://www.youtube.com/watch?v=0cu2ElcypyM',0.12),(202,66,38,192,'Bueno',-1,'Lote 1','En buen estado. Año 2009. Foto referencial','2016-06-06 16:58:00','2016-06-22 16:58:00',0,0,'finalizado',2000000,150000,2000000,'ce091.JPG','https://www.youtube.com/watch?v=WCSb87kXep4',0.12),(203,66,38,191,'Sin modelo',-1,'Lote 2','Año 2012. Casi nuevo','2016-06-13 17:02:00','2016-06-30 17:02:00',0,0,'activo',1500000,150000,1500000,'ce071.JPG','https://www.youtube.com/watch?v=cPQgc0GMRW0',0.12),(204,79,6,6,'Sin modelo',-1,'Lote 1','Sin des','2016-06-09 16:57:00','2016-06-09 16:59:00',0,0,'finalizado',100000,1000,100000,'ce012.JPG','https://www.youtube.com/watch?v=60QS57C8zBw',0.12);
/*!40000 ALTER TABLE `lotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marcas`
--

DROP TABLE IF EXISTS `marcas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marcas` (
  `marca_id` int(11) NOT NULL AUTO_INCREMENT,
  `marca_nombre` varchar(128) NOT NULL,
  `marca_estado` varchar(32) DEFAULT NULL,
  `categoria_id` int(11) NOT NULL,
  PRIMARY KEY (`marca_id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marcas`
--

LOCK TABLES `marcas` WRITE;
/*!40000 ALTER TABLE `marcas` DISABLE KEYS */;
INSERT INTO `marcas` (`marca_id`, `marca_nombre`, `marca_estado`, `categoria_id`) VALUES (1,'(Sin categoría - sin marca)','activo',1),(2,'(Auto o motos sin marca)','activo',2),(3,'(Camiones y autobuses sin marca)','activo',5),(4,'(Industrial, maquinaria y equipos sin marca)','activo',8),(5,'(Chatarra, material o residuo sin marca)','activo',15),(6,'Chevrolet','activo',2),(7,'Kia','activo',2),(8,'Peugeot','activo',2),(9,'Hyundai','activo',2),(10,'Volvo','activo',5),(11,'Mitsubishi','activo',5),(12,'Mercedes Benz','activo',5),(14,'(Movimiento y transporte sin marca)','activo',20),(15,'(Hogar y decoración sin marca)','activo',21),(16,'(Embarcaciones & Aeronaves sin marca)','activo',22),(17,'(Electrónicos, informática & bazar sin marca)','activo',23),(18,'(Bebidas y viajes sin marca)','activo',24),(19,'(Joyas y Relojes sin marca)','activo',25),(20,'Suzuki','activo',2),(21,'Audi','activo',2),(22,'Ford','activo',2),(23,'Mercedes Benz','activo',2),(24,'Nissan','activo',2),(25,'Renault','activo',2),(29,'Toyota','activo',2),(30,'Mazda','activo',2),(31,'Volkswagen','activo',2),(32,'Volvo','activo',2),(33,'BMW','activo',2),(34,'Daewoo','activo',2),(35,'Ford','activo',5),(36,'International','activo',5),(37,'Renault','activo',5),(38,'Freightliner','activo',5),(39,'Fuso','activo',5),(40,'Western Star','activo',5),(41,'Chevrolet','activo',5),(42,'Hyundai','activo',5),(43,'Scania','activo',5),(44,'Mack','activo',5),(45,'Kia','activo',5),(46,'Hino','activo',5),(47,'JAC Motors','activo',5),(48,'Iveco','activo',5),(49,'Foton','activo',5),(50,'Yuejin','activo',5),(51,'JMC','activo',5),(52,'Man','activo',5),(53,'Kenworth','activo',5),(54,'Dongfeng','activo',5),(55,'Isuzu','activo',5),(56,'Pegaso','activo',5),(57,'Dimex','activo',5),(58,'Sinotruck','activo',5),(59,'Toyota','activo',5),(60,'Nissan','activo',5),(61,'Faw','activo',5),(62,'Shacman','activo',5),(63,'Fiat','activo',5),(64,'Goren','activo',5),(65,'Abat','activo',5),(66,'Tremac','activo',5),(67,'Kamaz','activo',5),(68,'Great Dane','activo',5),(69,'Randon','activo',5),(70,'Utility','activo',5),(71,'Daihatsu','activo',5),(72,'Wabash','activo',5),(73,'Daf','activo',5),(74,'Agrale','activo',5),(75,'JBC','activo',5),(76,'Ural','activo',5),(77,'Kaufman','activo',5),(78,'Hechizo','activo',5),(79,'Mazda','activo',5),(80,'BAW','activo',5),(81,'Hafei','activo',5),(82,'Trayers','activo',5),(83,'Chery','activo',2),(84,'Chrysler','activo',2),(85,'Citroën','activo',2),(86,'Daihatsu','activo',2),(87,'Dodge','activo',2),(88,'Fiat','activo',2),(89,'Ford','activo',2),(90,'Foton','activo',2),(91,'Great Wall','activo',2),(92,'Honda','activo',2),(93,'JAC Motors','activo',2),(94,'Jeep','activo',2),(95,'Kawasaki','activo',2),(96,'Kia Motors','activo',2),(97,'KTM','activo',2),(98,'Land Rover','activo',2),(99,'Mahindra','activo',2),(100,'Mini Cooper','activo',2),(101,'Mitsubishi','activo',2),(102,'Opel','activo',2),(103,'Porsche','activo',2),(104,'Samsung','activo',2),(105,'Scania','activo',2),(106,'Ssangyong','activo',2),(107,'Subaru','activo',2),(108,'Triumph','activo',2),(109,'Yamaha','activo',2),(129,'(Maquinaria de construcción y agrícola sin marca)','activo',12),(157,'Hyster','activo',20),(158,'Yale','activo',20),(159,'Linde','activo',20),(160,'Komatsu','activo',20),(161,'Toyota','activo',20),(162,'Heli','activo',20),(163,'Nissan','activo',20),(164,'Liugong','activo',20),(165,'Caterpillar','activo',20),(166,'Mits','activo',20),(167,'Mitsubishi','activo',20),(168,'Lonking','activo',20),(169,'Hangcha','activo',20),(170,'Hyundai','activo',20),(171,'JCB','activo',20),(172,'John Henry','activo',20),(173,'Daewoo','activo',20),(174,'Dingo','activo',20),(175,'Doosan','activo',20),(176,'Hamm','activo',20),(177,'TCM','activo',20),(178,'XBH','activo',20),(179,'(Categoría de prueba 001111 sin marca)','activo',1),(180,'(Categoría de prueba 002 sin marca)','activo',1),(181,'(Categoría de prueba Imacom1 sin marca)','activo',1),(183,'(Categoría de prueba 0031 sin marca)','activo',1),(184,'Marca imacom 011','desactivado',1),(185,'(Categoría de prueba Imacom 1001 sin marca)','activo',1),(186,'Marca 011','desactivado',2),(187,'Marca prueba 01','desactivado',24),(188,'Marca prueba 01','activo',1),(189,'Marca prueba 01','activo',24),(190,'(Categoría de prueba 3 sin marca)','activo',1),(191,'Caterpillar','activo',12),(192,'Cat','activo',12),(193,'(Prueba sin marca)','activo',37),(194,'ejemplo marca edit','activo',37),(195,'(Super Prueba sin marca)','activo',38),(196,'(Prueba RSI sin marca)','activo',39);
/*!40000 ALTER TABLE `marcas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos`
--

DROP TABLE IF EXISTS `modelos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelos` (
  `modelo_id` int(11) NOT NULL AUTO_INCREMENT,
  `modelo_nombre` varchar(128) NOT NULL,
  `marca_id` int(11) NOT NULL,
  PRIMARY KEY (`modelo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos`
--

LOCK TABLES `modelos` WRITE;
/*!40000 ALTER TABLE `modelos` DISABLE KEYS */;
INSERT INTO `modelos` (`modelo_id`, `modelo_nombre`, `marca_id`) VALUES (1,'(Sin categoría - sin modelo)',1),(2,'(Auto o moto genérica sin modelo)',2),(3,'(Camión o autobús genérico sin modelo)',3),(4,'(Industria, maquinaria o equipo genérico sin modelo)',4),(5,'(Chatarra, material o residuo genérico sin modelo)',5),(6,'(Chevrolet sin modelo)',6),(7,'(Kia sin modelo)',7),(8,'(Peugeot sin modelo)',8),(9,'(Hyundai sin modelo)',9),(10,'(Volvo sin modelo)',10),(11,'(Mitsubishi sin modelo)',11),(12,'(Mercedes Benz sin modelo)',12),(13,'(Caterpillar sin modelo)',13),(14,'Montana',6),(15,'Besta',7),(16,'Partner',8),(17,'Elantra',9),(18,'Volvo',10),(19,'FH440',10),(20,'FH12',10),(21,'Canter',11),(22,'O-371',12),(23,'248',13),(24,'930',13),(25,'D6D',13);
/*!40000 ALTER TABLE `modelos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ofertantes`
--

DROP TABLE IF EXISTS `ofertantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ofertantes` (
  `ofertante_id` int(11) NOT NULL AUTO_INCREMENT,
  `ofertante_correo` varchar(255) NOT NULL,
  `ofertante_password` varchar(123) NOT NULL,
  `ofertante_nickname` varchar(45) NOT NULL,
  `ofertante_nombre` varchar(128) NOT NULL,
  `ofertante_apellido` varchar(128) NOT NULL,
  `ofertante_rut` varchar(12) DEFAULT NULL,
  `ofertante_fono` varchar(32) DEFAULT NULL,
  `ofertante_movil` varchar(32) DEFAULT NULL,
  `ofertante_direccion` varchar(255) DEFAULT NULL,
  `ofertante_ciudad` varchar(128) NOT NULL,
  `ofertante_region` varchar(128) DEFAULT NULL,
  `ofertante_pais` varchar(64) DEFAULT NULL,
  `ofertante_estado` varchar(32) NOT NULL,
  `ofertante_token_activacion` varchar(40) DEFAULT NULL,
  `ofertante_token_recuperar_clave` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`ofertante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ofertantes`
--

LOCK TABLES `ofertantes` WRITE;
/*!40000 ALTER TABLE `ofertantes` DISABLE KEYS */;
INSERT INTO `ofertantes` (`ofertante_id`, `ofertante_correo`, `ofertante_password`, `ofertante_nickname`, `ofertante_nombre`, `ofertante_apellido`, `ofertante_rut`, `ofertante_fono`, `ofertante_movil`, `ofertante_direccion`, `ofertante_ciudad`, `ofertante_region`, `ofertante_pais`, `ofertante_estado`, `ofertante_token_activacion`, `ofertante_token_recuperar_clave`) VALUES (-1,'sinofertante@rsiauction.com','202cb962ac59075b964b07152d234b70','root','sin ofertante','rsiauction','11111111-K','','','','Santiago','13','Chile','activo',NULL,NULL),(1,'clessx1@gmail.com','202cb962ac59075b964b07152d234b70','Cless','Cristian','Yanez','150691133','5555555','5555555','Las Rosas 28','Santiago','13','Chile','activo',NULL,NULL),(2,'soyunagargola@gmail.com','3502c914faf267732568d4f52a991049','ofertantexx','Cristian','Yanez','1-9','5555555','9999999','Santo Domingo 444','Santiago','13','Chile','activo',NULL,NULL),(3,'ofertante1@imacom.cl','81dc9bdb52d04dc20036dbd8313ed055','ofertante001','Ofertante','Uno','','','','','','13','Chile','activo',NULL,NULL),(4,'ofertante2@imacom.cl','81dc9bdb52d04dc20036dbd8313ed055','ofertante02','Ofertante','Dos','','','','','','13','Chile','activo',NULL,NULL),(5,'ofertante3@imacom.cl','81dc9bdb52d04dc20036dbd8313ed055','ofertante03','Ofertante','Tres','','','','','','13','Chile','activo',NULL,NULL),(7,'cristian1@imacom.cl','3502c914faf267732568d4f52a991049','cyanez','Cristian','Yáñez','15069113-3','72537215','72537215','Santo Domingo 444','Santiago','13','Chile','activo',NULL,NULL),(12,'eburgos1@imacom.cl','81dc9bdb52d04dc20036dbd8313ed055','esteban01','Esteban','Burgos Viveros','165314093-3','','77665730','las rosas 28','Padre Hurtado','13','Chile','activo','f3493608020eb38bd3838928d0e4c2041b490ac0',NULL),(13,'eburgos2@imacom.cl','81dc9bdb52d04dc20036dbd8313ed055','esteban02','Esteban','Burgos Viveros','165314093-3','','77665730','las rosas 28','Padre Hurtado','13','Chile','activo','f3493608020eb38bd3838928d0e4c2041b490ac0',NULL),(14,'cristian@imacom.cl','202cb962ac59075b964b07152d234b70','clessx','cristian','yanez','1-9','8888888','8888888','Santo Domingo','SANTIAGO','13','Chile','activo','d7c9795c950a8315f1d74d7cf9136d3c2ab73f8e',NULL),(16,'eburgos3@imacom.cl','81dc9bdb52d04dc20036dbd8313ed055','eburgos1','Esteban','Burgos','16531409-3','','45929303','las rosas 28','Padre Hurtado','13','Chile','activo','d0fc4f0f3043a108010741c320085408de440b07',NULL),(17,'eburgos@imacom.cl','81dc9bdb52d04dc20036dbd8313ed055','eburgos','Esteban','Burgo','16531409-3','','045929303','Las Rosas 28','Padre Hurtado','13','Chile','activo','891ef4f4087d12ec57ea8b728051e7b5f7312f09',NULL),(18,'LFORNO@REMATESANISIDRO.CL','ad83b1da9e1c728c89963a7b31c1c95c','blitzkriegg','LEONARDO','FORNO','15556641-8','+56976209373','','PANAMERICANA NORTE 5364','SANTIAGO','5','Chile','esperando','56292447daf5ad96643274ad2f260e24f2bdfe3a',NULL);
/*!40000 ALTER TABLE `ofertantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regiones`
--

DROP TABLE IF EXISTS `regiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regiones` (
  `region_id` int(11) NOT NULL AUTO_INCREMENT,
  `region_nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`region_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regiones`
--

LOCK TABLES `regiones` WRITE;
/*!40000 ALTER TABLE `regiones` DISABLE KEYS */;
INSERT INTO `regiones` (`region_id`, `region_nombre`) VALUES (1,'I Tarapacá'),(2,'II Antofagasta'),(3,'III Atacama'),(4,'IV Coquimbo'),(5,'V Valparaíso'),(6,'VI O\'Higgins'),(7,'VII Maule'),(8,'VIII Biobío'),(9,'IX La Araucanía'),(10,'X Los Lagos'),(11,'XI Aysén'),(12,'XII Magallanes y Antártica'),(13,'Región Metropolitana'),(14,'XIV Los Ríos'),(15,'XV Arica y Parinacota');
/*!40000 ALTER TABLE `regiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rematadores`
--

DROP TABLE IF EXISTS `rematadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rematadores` (
  `rematador_id` int(11) NOT NULL AUTO_INCREMENT,
  `rematador_correo` varchar(255) DEFAULT NULL,
  `rematador_nombre_empresa` varchar(128) DEFAULT NULL,
  `rematador_razon_social` varchar(128) DEFAULT NULL,
  `rematador_rut_empresa` varchar(12) DEFAULT NULL,
  `rematador_password` varchar(123) NOT NULL,
  `rematador_nombre_responsable` varchar(128) DEFAULT NULL,
  `rematador_apellido_responsable` varchar(128) NOT NULL,
  `rematador_rut_responsable` varchar(12) NOT NULL,
  `rematador_foto` varchar(255) DEFAULT NULL,
  `rematador_telefono` varchar(32) DEFAULT NULL,
  `rematador_movil` varchar(32) DEFAULT NULL,
  `rematador_direccion` varchar(255) DEFAULT NULL,
  `rematador_ciudad` varchar(64) NOT NULL,
  `rematador_region` int(11) NOT NULL,
  `rematador_pais` varchar(64) DEFAULT NULL,
  `rematador_descripcion_activos` varchar(1024) DEFAULT NULL,
  `rematador_estado` varchar(32) NOT NULL,
  `rematador_token_activacion` varchar(40) DEFAULT NULL,
  `rematador_token_recuperar_clave` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`rematador_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rematadores`
--

LOCK TABLES `rematadores` WRITE;
/*!40000 ALTER TABLE `rematadores` DISABLE KEYS */;
INSERT INTO `rematadores` (`rematador_id`, `rematador_correo`, `rematador_nombre_empresa`, `rematador_razon_social`, `rematador_rut_empresa`, `rematador_password`, `rematador_nombre_responsable`, `rematador_apellido_responsable`, `rematador_rut_responsable`, `rematador_foto`, `rematador_telefono`, `rematador_movil`, `rematador_direccion`, `rematador_ciudad`, `rematador_region`, `rematador_pais`, `rematador_descripcion_activos`, `rematador_estado`, `rematador_token_activacion`, `rematador_token_recuperar_clave`) VALUES (1,'esteban.imacom1@gmail.com','Tanner Servicios Financieros','Servicios de Ingeniería','11.111.111-K','7153f086973eda155b48b8d101205d8b','Esteban','Burgos','16.531.409-3','c0.jpg',NULL,'09-77665730','Cheuque 01865','Temuco',9,'Chile','Descripción del activos 01','activo',NULL,NULL),(2,'hguerra@xinergia.cl','Xinergia Ltda.','Servicios de Ingeniería','76.785.280-0','7153f086973eda155b48b8d101205d8b','Héctor','Guerra','8.378.922-0','c1.jpg','02-3282100',NULL,'Arzobispo Larraín Gandarillas Nº 125','Santiago',13,'Chile','Descripción del activos 02','activo',NULL,NULL),(3,'serviciocliente@klait.cl','Grupo Saesa Ltda.','Servicios de Ingeniería','76.750.650-3','7153f086973eda155b48b8d101205d8b','Claudio','Iturriaga','6.192.349-7','c2.jpg','057-573120',NULL,'Obispo Labbé 1280','Iquique',1,'Chile','Descripción del activos 03','activo',NULL,NULL),(4,'ecaser@terra.cl','Banco Falabella','Servicios de Ingeniería','79.602.090-3','7153f086973eda155b48b8d101205d8b','María Teresa','Reyes','4.213.080-K','c3.jpg','02-3671830',NULL,'Monjitas 527, Oficina 1017','Santiago',13,'Chile','Descripción del activos 04','activo',NULL,NULL),(5,'servicios@dimacltda.cl','Dimac Est Limitada','Servicios de Ingeniería','76.426.336-7','7153f086973eda155b48b8d101205d8b','Enrique','Contreras','12.062.051-7','c4.jpg','02-26970350',NULL,'Huérfanos N°1022, Of.506','Santiago',13,'Chile','Descripción del activos 05','activo',NULL,NULL),(8,'soporte@imacom.cl','Imasupremo','Imasupremo','12-8','81dc9bdb52d04dc20036dbd8313ed055','Juan','Delas','19-1','sinfoto.jpg','5555-5555','9999-9999','Las Rosas 28','Santiago',13,NULL,'no tengo','activo',NULL,NULL),(17,'eburgos1@imacom.cl','Imacom prueba 1','Imacom','16531409-4','81dc9bdb52d04dc20036dbd8313ed055','Esteban','Burgos','16531409-3','sinfoto.jpg','222222222','77665730','Av Viel 1124','Santiago',13,'Chile','descripcion de activos prueba 1','activo',NULL,'722dd1299219455a2617978ad198b1ade27893c0'),(18,'clessx1@gmail.com','Imacom Soporte','Imacom','1-9','e10adc3949ba59abbe56e057f20f883e','Cristian','Yáñez','1-9','sinfoto.jpg','9999-9999','5555-5555','Las Rosas 28','Padre Hurtado',13,'Chile','Texto de prueba									','activo',NULL,NULL),(24,'alvaro1@imacom.cl','Imacom','Imacom','1-9','e10adc3949ba59abbe56e057f20f883e','Cristian','Yáñez','15069113-3','sinfoto.jpg','72572123','156456456','Las Rosas 28','Santiago',13,'Chile','																																																																		','activo',NULL,NULL),(59,'webmaster1@imacom.cl','Imacom','Imacom','1-9','3502c914faf267732568d4f52a991049','Cristian','Yanez','15069113-3','sinfoto.jpg','888888','888888','Las Rosas 28','Santiago',13,'Chile','																																												','activo',NULL,NULL),(77,'eburgos@imacom.cl','Imacom','Servicios de Ingeniería','16531409-3','81dc9bdb52d04dc20036dbd8313ed055','Esteban','Burgos','16531409-3','logo_400x400.jpeg','','77665730','las rosas 28','Padre Hurtado',13,'Chile','D.\nActivos\n01											','activo','2a0b9cabfe44c9c7a53a9d188444898697bfd9e4',NULL),(78,'criyala1@gmail.com','fsdfsdf','fsdfsd','sffsdf','3502c914faf267732568d4f52a991049','sdfsdf','sdf','sdf','sinfoto.jpg','234324','23424','sdffsd','fsdfdsf',1,'Chile','																																','activo','c11607f1a1bdd51e9e20ed37bdf1a30b8a8eafc3',NULL);
/*!40000 ALTER TABLE `rematadores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remates`
--

DROP TABLE IF EXISTS `remates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remates` (
  `remate_id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) NOT NULL,
  `rematador_id` int(11) NOT NULL,
  `remate_nombre` varchar(128) NOT NULL,
  `remate_comuna` varchar(128) NOT NULL,
  `remate_direccion` varchar(255) DEFAULT NULL,
  `remate_nombre_mandante` varchar(128) DEFAULT NULL,
  `remate_imagen` varchar(255) DEFAULT NULL,
  `remate_fecha_creacion` datetime NOT NULL,
  `remate_fecha_inicio` datetime DEFAULT NULL,
  `remate_fecha_termino` datetime DEFAULT NULL,
  `remate_tipo` varchar(32) NOT NULL,
  `remate_estado` varchar(32) NOT NULL,
  `remate_contador_visitas` int(11) NOT NULL DEFAULT '0',
  `remate_contador_ofertas` int(11) DEFAULT '0',
  `remate_plazo_garantia` datetime DEFAULT NULL,
  `remate_descripcion` varchar(1024) DEFAULT NULL,
  `remate_precio_garantia` bigint(20) NOT NULL,
  PRIMARY KEY (`remate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remates`
--

LOCK TABLES `remates` WRITE;
/*!40000 ALTER TABLE `remates` DISABLE KEYS */;
INSERT INTO `remates` (`remate_id`, `categoria_id`, `rematador_id`, `remate_nombre`, `remate_comuna`, `remate_direccion`, `remate_nombre_mandante`, `remate_imagen`, `remate_fecha_creacion`, `remate_fecha_inicio`, `remate_fecha_termino`, `remate_tipo`, `remate_estado`, `remate_contador_visitas`, `remate_contador_ofertas`, `remate_plazo_garantia`, `remate_descripcion`, `remate_precio_garantia`) VALUES (1,8,1,'1° Licitación Tanner','Padre Hurtado','Las Rosas 28','Tanner Servicios Financieros','sinfoto.jpg','2015-08-28 00:00:00','2015-08-28 11:00:00','2015-11-01 10:30:00','Tipo 01','finalizado',10,0,'2015-09-09 00:00:00','Subasta Empresa Tanner Ltda.',0),(2,2,5,'Remate de motores camionetas','Maipú','Camino a Melipilla 1200','Dimac Est Limitada','sinfoto.jpg','2015-10-08 00:00:00','2015-10-08 16:00:00','2016-02-28 10:00:00','Tipo 02','finalizado',4,0,'2015-10-20 00:00:00','Motores de Camionetas oxidados',0),(3,5,4,'Excedentes de Carrocerías','Santiago','Av. Matta 506','Banco Falabella','sinfoto.jpg','2015-10-08 00:00:00','2015-10-08 14:00:00','2016-02-17 08:00:00','Tipo 03','finalizado',0,0,'2015-11-12 00:00:00','Carrocerías de diferentes marcas',0),(4,8,5,'Transformadores 400 KVA','Cerrillos','Av. Pedro Aguirre Cerca 1200','Dimac Est Limitada','sinfoto.jpg','2015-10-08 00:00:00','2015-10-08 19:30:00','2015-11-02 12:00:00','Tipo 04','finalizado',0,0,'2015-11-12 00:00:00','Transformadores en buen estado',0),(5,2,1,'2° Licitación Tanner','Santiago','Dirección 02','Tanner Servicios Financieros','sinfoto.jpg','2015-10-27 00:00:00','2015-10-27 13:45:00','2016-03-24 13:00:00','Tipo 05','finalizado',44,9,'2015-10-20 00:00:00','Remate Sedan',0),(6,2,3,'Remate camiones deteriorados','Melipilla','Melipilla 1010','Grupo Saesa Ltda.','sinfoto.jpg','2015-11-18 00:00:00','2015-11-18 14:15:00','2016-02-10 12:45:00','Tipo 03','finalizado',0,0,'2015-11-12 00:00:00','Camiiones por partes',0),(7,5,2,'Remate repuestos de camiones','Peñaflor','Av. Poniente 404','Xinergia Ltda.','sinfoto.jpg','2015-11-18 00:00:00','2015-11-18 17:00:00','2015-11-17 14:00:00','Tipo 05','finalizado',0,0,'2015-11-12 00:00:00','Piezas de camiones de carga',0),(8,2,1,'Remate autos siniestrados','Padre Hurtado','Av. Oriente 303','Tanner Servicios Financieros','sinfoto.jpg','2015-11-18 00:00:00','2015-11-18 09:00:00','2016-02-24 20:00:00','Tipo 05','finalizado',0,0,'2015-11-12 00:00:00','Autos de diferentes marcas',0),(26,2,4,'1° Licitacion BancoFalabella','Las Condes','Av. Padre Hurtado 1001','Banco Falabella','sinfoto.jpg','2015-11-23 00:00:00','2015-11-23 12:00:00','2016-03-23 20:00:00','Tipo 08','finalizado',3,1,'2015-11-12 00:00:00','Vehículos de trasporte corporativo',0),(40,2,17,'1° Licitación Imacom','Cerrillos','Av. Buzeta 1201','	\nImacom prueba 1','sinfoto.jpg','2015-11-30 00:00:00','2015-11-30 23:00:00','2016-03-18 23:00:00','Tipo 08','finalizado',11,0,'2015-11-12 00:00:00','Remate de autos',0),(41,2,8,'1° Licitación Excedentes','Quilicura','M. Matta 1001','	\nImacom prueba 1','sinfoto.jpg','2015-11-30 00:00:00','2015-11-30 00:00:00','2016-03-21 02:00:00','Tipo 08','finalizado',62,1,'2015-11-12 00:00:00','Excedente de vehículos',0),(43,2,17,'Remate automóviles siniestrados','Lo Padro','Dorsal 2010','	\nImacom prueba 1','sinfoto.jpg','2015-12-01 00:00:00','2015-12-01 23:00:00','2016-05-17 23:00:00','Tipo 08','finalizado',13,0,'2015-11-12 00:00:00','Vehículos deteriorados',0),(44,2,59,'Remate de Prueba  RSI','Santiago','Las Rosas 28','Imacom','sinfoto.jpg','2015-12-10 00:00:00','2015-12-31 09:00:00','2016-04-19 18:00:00','Ejenplo','finalizado',0,0,'0000-00-00 00:00:00','Remate de prueba',0),(46,2,77,'Remate de prueba 001','Santiago Centro','Av. Matta 100','Imacom','sinfoto.jpg','2016-02-04 00:00:00','2016-02-04 09:00:00','2016-03-31 20:00:00','Tipo 001','finalizado',24,3,'2016-03-12 00:00:00','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur enim eget interdum laoreet. Nulla id augue rutrum, facilisis libero in, tristique risus. Nulla sed aliquet felis. Suspendisse vehicula id ex in vehicula. Ut eu metus viverra, laoreet libero et, molestie diam. Suspendisse potenti. Suspendisse ut feugiat metus. Ut molestie libero in hendrerit tristique. Aenean ultricies id est eu dignissim. Quisque efficitur sapien ipsum, eget imperdiet nisl ornare nec. Sed non lacinia odio. Vestibulum augue mi, aliquam in molestie non, auctor at nulla. Proin vel tempor ipsum.',0),(57,2,17,'Remate prueba 1000','Santiago Centro','Av. Matta 1001','Imacom prueba 1','sinfoto.jpg','2016-02-22 20:57:44','2016-02-22 17:57:00','2016-03-31 17:57:00','Tipo 1001','finalizado',14,0,'2016-02-26 00:00:00','ads',0),(58,2,78,'Las Super Motos','Santiago Centro','Santo Domingo con Catedral','fsdfsdf','sinfoto.jpg','2016-03-15 20:45:09','2016-03-31 17:45:00','2016-04-01 17:45:00','Especial','finalizado',3,0,'2016-03-30 00:00:00','El mejor remate de motos de Chile',0),(59,2,8,'Remate de prueba RSI 001','Conchalí','Calle Pdte Eduardo Frei Montalva 4019','Imasupremo2','sinfoto.jpg','2016-03-22 21:36:49','2016-03-22 18:39:00','2016-04-01 19:00:00','Tipo 001','finalizado',1,0,'2016-03-31 00:00:00','Remate de prueba 001',0),(60,5,8,'Remate de prueba RSI 002','Conchalí','Calle Pdte Eduardo Frei Montalva 4019','Imasupremo','sinfoto.jpg','2016-03-22 21:41:20','2016-03-21 18:00:00','2016-04-22 11:30:00','Tipo 002','finalizado',6,0,'2016-03-30 00:00:00','Remate de prueba 576576',0),(61,2,8,'Remate de prueba RSI 003','Conchalí','Calle Pdte Eduardo Frei Montalva 4019','Imasupremo','sinfoto.jpg','2016-03-22 21:42:31','2016-03-22 19:00:00','2016-05-02 19:00:00','Tipo 003','finalizado',0,0,'2016-03-31 00:00:00','Remate de prueba 003',0),(62,12,8,'Komatsu','stgo','panamericana.........','Imasupremo','komatsu.jpg','2016-04-02 01:20:53','2016-04-30 22:17:00','2016-05-31 22:22:00','remate con derecho a consulta','finalizado',5,1,'2016-04-22 00:00:00','esta es una prueba realizada por leonardo forno c',1000000),(63,22,8,'PUREBA DOB','SANTIAGO','PANAMERICANA NORTE 5364','Imasupremo','sinfoto.jpg','2016-04-04 19:16:46','2016-04-05 16:30:00','2016-04-05 17:30:00','QUE ES?','finalizado',11,0,'2016-04-03 00:00:00','BARCOS Y AVIONES',0),(64,25,8,'prueba lafc 2','valpo','micasa, 555, ','Imasupremo','sinfoto.jpg','2016-04-04 19:16:45','2016-04-04 16:31:00','2016-04-04 17:37:00','???','finalizado',4,0,'2016-04-03 00:00:00','aca va una breve descripcion de la subasta',0),(65,8,8,'PRUEBA 2','SANTIAGO','PANAMERICANA NORTE 5364','Imasupremo','sinfoto.jpg','2016-04-04 22:58:26','2016-04-04 20:10:00','2016-04-04 20:30:00','DOB','finalizado',0,0,'2016-04-04 00:00:00','MAQUINARIAS',0),(66,12,8,'Remate de maquinaria y equipos','Antofagasta','Angamos 01455','OUTOTEC','c2.png','2016-04-12 02:50:49','2016-04-11 23:00:00','2016-07-28 23:30:00','','activo',8,0,'2016-05-02 00:00:00','Camiones varios dados de baja',0),(67,12,8,'Remate de vehículos deteriorados','Cerrillos','Camino Melipilla 1001','Pedro Romero','c31.jpg','2016-04-12 03:37:37','2016-04-12 00:30:00','2016-06-30 12:00:00','','activo',64,0,'2016-05-05 00:00:00','Descrip 002',0),(68,12,8,'Subasta Licitación Siniestrados','Vitacura','Alonso de Monroy 2677 - of. 502','Penta Security y Liberty Seguros','c1.png','2016-04-12 03:50:52','2016-04-10 00:00:00','2016-07-07 00:45:00','','activo',1,0,'2016-05-05 00:00:00','Remate de camiones y otros ',0),(69,2,8,'Remate de prueba de autos 001','Santiago Centro','Balmaceda 1001','Imasupremo','logo_remate.jpg','2016-04-12 18:35:56','2016-04-12 15:00:00','2016-04-30 15:00:00','','finalizado',0,0,'2016-04-28 00:00:00','Autos usados sin motor',500000),(70,5,8,'Remate de prueba de camiones 001','Santiago Centro','Av. Manuel Rodríguez 1010','Juan Pedro Pérez Pereira','logo_remate1.jpg','2016-04-12 19:59:19','2016-04-12 10:00:00','2016-04-29 11:00:00','','finalizado',39,0,'2016-04-26 00:00:00','Descripción camiones 005',200000),(71,2,8,'Autos nuevos','Santiago','Las Rosas 28','Imacom','Imagen-Vectorial_(1).jpg','2016-04-13 14:28:38','2016-04-01 11:29:00','2016-04-30 11:29:00','','finalizado',0,0,'2016-04-13 00:00:00','Test',100000),(72,24,8,'Subasta Licitación N°1','Santiago Centro','las rosas 28','Juan Pérez','0_1112301430.jpg','2016-05-17 22:09:21','2016-05-17 18:10:00','2016-06-30 18:10:00','','finalizado',46,4,'2016-05-19 00:00:00','Descripción remate 001',100000),(73,12,8,'Subasta de Camiones Bulldozers','Santiago Centro','las rosas 28','Juan Pérez','cat.jpg','2016-05-23 22:15:33','2016-05-23 18:18:00','2016-07-22 18:18:00','','activo',7,1,'2016-06-01 00:00:00','Remate sólo de marca Cat',500000),(74,1,8,'Remate prueba 99','Estación Central','Exposición 1001','María Fernanda Soto','volvo.jpg','2016-05-25 22:20:01','2016-05-25 18:21:00','2016-06-29 18:21:00','','finalizado',0,0,'2016-06-07 00:00:00','Volvo auto azul',1000000),(75,12,8,'Remate Maquinaria Siniestrada','Santiago Centro','las rosas 28','Juan Pérez','simma.jpg','2016-05-31 16:51:59','2016-05-31 12:00:00','2016-06-30 12:00:00','','activo',100,15,'2016-06-06 00:00:00','Descripción de prueba maquinaria 01',100000),(76,5,8,'Maquinaria y equipos a disposición','Antofagasta','Angamos 01455','Minera Los Pelambres','minera.jpg','2016-06-01 17:18:18','2016-06-01 13:00:00','2016-07-25 13:00:00','','activo',1,0,'2016-06-14 00:00:00','Maquinaría a disposición',400000),(77,12,8,'Subasta N°1 Licitacion Skanka','Vitacura','Alonso de Monroy 2677 - of. 502','Tanner Ltda.','c41.jpg','2016-06-01 17:27:08','2016-06-01 13:30:00','2016-07-29 13:30:00','','activo',1,0,'2016-06-16 00:00:00','Licitación de vehículos en bodega',200000),(78,2,8,'Subasta N°2 Vehículos siniestrados','Santiago Centro','Balmaceda 1001','Grupo Saesa Spa','101.jpg','2016-06-01 17:59:47','2016-06-01 14:00:00','2016-07-29 14:00:00','','activo',0,0,'2016-06-23 00:00:00','Chatarra de vehículos en bodega',300000),(79,2,77,'Remate para cerrar 01','Santiago Centro','Blanco 101','Juan Pérez','c7.jpg','2016-06-09 20:50:53','2016-06-09 16:45:00','2016-06-09 17:00:00','','finalizado',0,0,'2016-06-09 00:00:00','Lorem ipsus',500000);
/*!40000 ALTER TABLE `remates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesiones`
--

DROP TABLE IF EXISTS `sesiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sesiones` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesiones`
--

LOCK TABLES `sesiones` WRITE;
/*!40000 ALTER TABLE `sesiones` DISABLE KEYS */;
INSERT INTO `sesiones` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d37791e1ec4353e682ec9b64c34a3d4b','186.79.40.243','Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0',1440168131,'a:7:{s:9:\"user_data\";s:0:\"\";s:2:\"id\";s:1:\"1\";s:5:\"email\";s:17:\"soporte@imacom.cl\";s:7:\"permiso\";a:1:{i:0;s:5:\"admin\";}s:6:\"nombre\";s:8:\"Cristian\";s:16:\"apellido_paterno\";s:5:\"Yanez\";s:4:\"auth\";b:1;}'),('d908c1eeb7abc4aa5796d9f1ac1fc7f6','186.79.40.243','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',1440166919,'');
/*!40000 ALTER TABLE `sesiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subastas`
--

DROP TABLE IF EXISTS `subastas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subastas` (
  `subasta_id` int(11) NOT NULL AUTO_INCREMENT,
  `lote_id` int(11) NOT NULL,
  `ofertante_id` int(11) NOT NULL,
  `subasta_valor` bigint(20) DEFAULT NULL,
  `subasta_total` int(11) NOT NULL,
  `subasta_fecha` datetime NOT NULL,
  PRIMARY KEY (`subasta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subastas`
--

LOCK TABLES `subastas` WRITE;
/*!40000 ALTER TABLE `subastas` DISABLE KEYS */;
INSERT INTO `subastas` (`subasta_id`, `lote_id`, `ofertante_id`, `subasta_valor`, `subasta_total`, `subasta_fecha`) VALUES (16,3,3,1500,5500,'0000-00-00 00:00:00'),(17,3,4,1000,6500,'2015-11-30 00:00:00'),(18,3,3,2000,8500,'2015-11-30 19:29:25'),(19,3,4,2000,10500,'2015-11-30 21:51:47'),(20,3,3,2000,12500,'2015-12-03 21:00:02'),(21,3,7,2000,14500,'2015-12-03 21:01:27'),(22,31,7,10,1010,'2015-12-03 21:02:37'),(23,8,7,300,6800,'2015-12-04 13:53:34'),(24,3,3,500,15000,'2015-12-04 16:33:35'),(25,3,5,2000,17000,'2015-12-04 17:31:54'),(26,3,3,1000,18000,'2015-12-04 17:36:16'),(27,32,3,20,1020,'2015-12-04 17:56:03'),(28,9,3,300,5300,'2015-12-10 12:17:33'),(29,9,4,200,5500,'2015-12-10 12:20:41'),(30,35,12,200,5200,'2016-02-09 18:01:00'),(31,35,13,100,5300,'2016-02-09 18:14:26'),(32,35,12,200,5500,'2016-02-10 13:04:15'),(33,9,14,400,5900,'2016-03-23 12:34:12'),(34,48,3,3000,453000,'2016-05-17 13:20:12'),(35,48,4,3000,456000,'2016-05-17 13:26:10'),(36,48,3,4000,460000,'2016-05-17 13:27:30'),(37,48,4,4000,464000,'2016-05-17 13:27:54'),(38,124,16,50000,500000,'2016-05-23 19:52:42'),(46,123,16,5000,55000,'2016-05-27 17:01:17'),(48,123,12,5000,60000,'2016-05-28 14:44:52'),(49,123,13,5000,65000,'2016-05-28 15:05:28'),(52,123,12,5000,70000,'2016-05-28 15:47:38'),(53,126,4,5,10005,'2016-05-31 17:09:31'),(54,126,3,5,10010,'2016-05-31 17:14:50'),(55,126,4,20,10030,'2016-05-31 17:16:40'),(56,126,3,10000,30000,'2016-05-31 17:34:29'),(57,126,4,10000,30030,'2016-05-31 17:36:41'),(58,126,3,15000,45030,'2016-05-31 17:52:40'),(59,126,4,10000,55030,'2016-05-31 18:25:58'),(60,126,3,10000,65030,'2016-05-31 18:26:16'),(61,126,4,15000,80030,'2016-05-31 18:26:34'),(62,126,3,10000,90030,'2016-05-31 18:27:17'),(63,126,4,10000,100030,'2016-05-31 18:27:45'),(64,126,3,20000,120030,'2016-05-31 18:45:40'),(65,126,4,20000,140030,'2016-05-31 18:46:07'),(66,126,3,15000,155030,'2016-05-31 18:46:29'),(67,126,4,5000,160030,'2016-05-31 18:55:14'),(68,129,3,2000,2000,'2016-05-31 19:24:14'),(69,183,17,150000,1150000,'2016-06-02 18:08:38');
/*!40000 ALTER TABLE `subastas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos`
--

DROP TABLE IF EXISTS `tipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos` (
  `tipo_id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_nombre` varchar(128) NOT NULL,
  `tipo_estado` varchar(32) DEFAULT NULL,
  `categoria_id` int(11) NOT NULL,
  PRIMARY KEY (`tipo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos`
--

LOCK TABLES `tipos` WRITE;
/*!40000 ALTER TABLE `tipos` DISABLE KEYS */;
INSERT INTO `tipos` (`tipo_id`, `tipo_nombre`, `tipo_estado`, `categoria_id`) VALUES (1,'(Sin categoría - sin tipo)','activo',1),(2,'(Auto o motos sin tipo)','activo',2),(3,'(Camiones y autobuses sin tipo)','activo',5),(4,'(Industrial, maquinaria y equipos sin tipo)','activo',8),(5,'(Chatarra, material o residuo sin tipo)','activo',15),(6,'Camioneta o Pick ups','activo',2),(7,'Ambulancia','activo',2),(8,'Utilitarios y furgones','activo',2),(9,'Sedans','activo',2),(10,'Camiones sin remolque','activo',5),(11,'Tracto camiones','activo',5),(12,'Camiones furgón','activo',5),(13,'Autobuses Urbanos','activo',5),(17,'Chatarra de inoxidables','activo',15),(18,'Chatarra de muebles','activo',15),(19,'Chatarra informática','activo',15),(20,'Piezas metálicas','activo',15),(21,'(Movimiento y transporte sin tipo)','activo',20),(27,'Deportivo','activo',2),(28,'Todoterreno','activo',2),(29,'Hatchback','activo',2),(30,'SUV','activo',2),(31,'Jeeps','activo',2),(32,'Minibuses','activo',2),(33,'Chatarra','activo',2),(34,'Camiones Volquetas','activo',5),(35,'Camiones Plataforma Abierta','activo',5),(36,'Autobuses Urbanos','activo',5),(37,'Grúa','activo',5),(38,'(Maquinaria de construcción y agrícola sin tipo)','activo',12),(40,'(Chatarras, materiales y residuos sin tipo)','activo',15),(41,'Chatarra de madera','activo',15),(43,'Grúas Horquillas','activo',20),(44,'(Hogar y decoración sin tipo)','activo',21),(45,'(Embarcaciones & Aeronaves sin tipo)','activo',22),(46,'(Electrónicos, informática & bazar sin tipo)','activo',23),(47,'(Bebidas y viajes sin tipo)','activo',24),(48,'(Joyas y Relojes sin tipo)','activo',25),(53,'(Categoría de prueba 001111 sin tipo)','activo',1),(54,'(Categoría de prueba 002 sin tipo)','activo',1),(55,'(Categoría de prueba Imacom1 sin tipo)','activo',1),(57,'(Categoría de prueba 0031 sin tipo)','activo',1),(58,'Tipo prueba 1','activo',1),(59,'Tipo prueba 2','desactivado',1),(64,'Tipo prueba 3','desactivado',1),(65,'Tipo prueba 4','desactivado',1),(66,'Tipo de prueba Imacom 01','desactivado',1),(67,'Tipo de prueba Imacom 001','desactivado',1),(68,'Tipo de prueba Imacom 002','desactivado',1),(69,'Tipo de prueba Imacom 003','desactivado',1),(70,'Tipo de prueba Imacom 004','desactivado',1),(71,'maquinaria minera','activo',2),(72,'(Categoría de prueba Imacom 1001 sin tipo)','activo',1),(73,'Tipo prueba 111','desactivado',2),(74,'Tipo prueba 1','desactivado',24),(75,'Tipo prueba 1','activo',1),(76,'Tipo prueba 1','activo',24),(77,'(Categoría de prueba 3 sin tipo)','activo',1),(78,'Bulldozers','activo',12),(79,'(Prueba sin tipo)','activo',37),(80,'(Super Prueba sin tipo)','activo',38),(81,'(Prueba RSI sin tipo)','activo',39),(82,'Pequenos','activo',39);
/*!40000 ALTER TABLE `tipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'imacomre_sys'
--

--
-- Dumping routines for database 'imacomre_sys'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-23 14:48:22
